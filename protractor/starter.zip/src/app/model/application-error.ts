export class ApplicationError {
  errorNumber: number;
  errorMsg: string;
}
